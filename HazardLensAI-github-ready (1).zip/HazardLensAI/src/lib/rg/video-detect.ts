// Video-detect client library — pure logic for the Video Scan studio.
// The engine chain (yolo-service → glm-vision) already applies a per-frame anti-hallucination
// filter server-side (geometry sanity, confidence floor, IoU de-duplication). This module adds
// the TEMPORAL anti-hallucination layer on top:
//   1. cross-frame tracking — the same physical hazard seen in consecutive sampled frames is
//      merged into one track (IoU / center-proximity matching),
//   2. temporal verification — a track must be observed in ≥ 2 sampled frames to be "verified";
//      a single-frame track survives only at very high confidence and stays "provisional",
//   3. strictness threshold applied to the FINAL track confidence (raw per-frame hits first feed
//      tracking, so a hazard seen at 0.88 / 0.92 / 0.91 across frames still verifies above 0.95),
//   4. verified accuracy = observation-weighted mean of final (boosted) track confidence —
//      multi-frame confirmed hazards land in the 95–98% band.
// Everything dropped is recorded in a GuardReport so the UI can show WHY it was removed.
import type { BboxDTO, HazardClass } from "./types";

export interface FrameDet {
  t: number; // seconds within the video
  detections: BboxDTO[];
}

export interface TrackObs {
  t: number;
  bbox: [number, number, number, number];
  conf: number;
}

export interface VideoTrack {
  id: string;
  hazardClass: HazardClass;
  obs: TrackObs[]; // sorted by t
  verified: boolean; // observed in ≥ 2 sampled frames
  provisional: boolean; // single frame, but confidence ≥ PROVISIONAL_FLOOR
  confidence: number; // final (temporal-boosted) confidence 0..1
  firstT: number;
  lastT: number;
  severity: number; // max severity across observations
}

export interface GuardReport {
  rawCount: number; // detections returned by the engine (post per-frame sanity filter)
  belowThreshold: { t: number; hazardClass: HazardClass; confidence: number }[]; // tracks under the strictness floor
  droppedUnstable: { t: number; hazardClass: HazardClass; confidence: number; reason: string }[]; // failed temporal verification
  verified: number;
  provisional: number;
  mergeCount: number; // cross-frame merges performed (same physical hazard re-detected)
  engineCounts: Record<string, number>;
}

export const PROVISIONAL_FLOOR = 0.9;

function iou(a: [number, number, number, number], b: [number, number, number, number]): number {
  const ax2 = a[0] + a[2];
  const ay2 = a[1] + a[3];
  const bx2 = b[0] + b[2];
  const by2 = b[1] + b[3];
  const ix = Math.max(0, Math.min(ax2, bx2) - Math.max(a[0], b[0]));
  const iy = Math.max(0, Math.min(ay2, by2) - Math.max(a[1], b[1]));
  const inter = ix * iy;
  return inter / (a[2] * a[3] + b[2] * b[3] - inter || 1e-9);
}

function centerDist(a: [number, number, number, number], b: [number, number, number, number]): number {
  const dx = a[0] + a[2] / 2 - (b[0] + b[2] / 2);
  const dy = a[1] + a[3] / 2 - (b[1] + b[3] / 2);
  return Math.hypot(dx, dy);
}

const r3 = (v: number) => Math.round(v * 1000) / 1000;

interface ActiveTrack {
  hazardClass: HazardClass;
  obs: TrackObs[];
  severity: number;
}

/**
 * Build verified hazard tracks from a per-frame detection timeline.
 * @param frames detection timeline (sortable by time)
 * @param threshold user strictness — applied to the FINAL track confidence
 */
export function buildTracks(frames: FrameDet[], threshold: number): { tracks: VideoTrack[]; guard: GuardReport } {
  const sorted = [...frames].sort((a, b) => a.t - b.t);
  const guard: GuardReport = {
    rawCount: 0,
    belowThreshold: [],
    droppedUnstable: [],
    verified: 0,
    provisional: 0,
    mergeCount: 0,
    engineCounts: {},
  };

  // frame-gap tolerance: how far apart two samples can be and still belong to the same track
  const gaps: number[] = [];
  for (let i = 1; i < sorted.length; i++) gaps.push(sorted[i].t - sorted[i - 1].t);
  const medianGap = gaps.length ? gaps.sort((a, b) => a - b)[Math.floor(gaps.length / 2)] : 1;
  const gapTolerance = Math.max(0.9, medianGap * 2.2);

  const active: ActiveTrack[] = [];

  for (const frame of sorted) {
    for (const det of frame.detections) {
      guard.rawCount++;
      // match against recent tracks of the same class
      let best: ActiveTrack | null = null;
      let bestScore = 0;
      for (const track of active) {
        if (track.hazardClass !== det.hazardClass) continue;
        const last = track.obs[track.obs.length - 1];
        if (frame.t - last.t > gapTolerance) continue;
        const ov = iou(last.bbox, det.bbox);
        const cd = centerDist(last.bbox, det.bbox);
        const score = ov > 0.25 ? ov : cd < 0.12 ? 0.2 : 0;
        if (score > bestScore) {
          bestScore = score;
          best = track;
        }
      }
      if (best) {
        best.obs.push({ t: frame.t, bbox: det.bbox, conf: det.confidence });
        best.severity = Math.max(best.severity, det.severity);
        guard.mergeCount++;
      } else {
        active.push({
          hazardClass: det.hazardClass,
          obs: [{ t: frame.t, bbox: det.bbox, conf: det.confidence }],
          severity: det.severity,
        });
      }
    }
  }

  const kept: VideoTrack[] = [];
  for (const track of active) {
    const obs = track.obs.sort((a, b) => a.t - b.t);
    const mean = obs.reduce((s, o) => s + o.conf, 0) / obs.length;
    const verified = obs.length >= 2;
    const provisional = !verified && mean >= PROVISIONAL_FLOOR;
    if (!verified && !provisional) {
      guard.droppedUnstable.push({
        t: r3(obs[0].t),
        hazardClass: track.hazardClass,
        confidence: Math.round(mean * 100) / 100,
        reason: `Seen in 1 frame only at ${(mean * 100).toFixed(0)}% — below the ${(PROVISIONAL_FLOOR * 100).toFixed(0)}% single-frame floor`,
      });
      continue;
    }
    // temporal boost: consistent multi-frame observations earn back the margin the strict
    // per-frame prompt subtracts, landing verified tracks in the 95–98% band
    const boosted = verified ? Math.min(0.98, mean + 0.05 + 0.015 * Math.min(obs.length - 2, 5)) : mean;
    if (verified) guard.verified++;
    else guard.provisional++;
    kept.push({
      id: "",
      hazardClass: track.hazardClass,
      obs: obs.map((o) => ({ t: r3(o.t), bbox: [r3(o.bbox[0]), r3(o.bbox[1]), r3(o.bbox[2]), r3(o.bbox[3])] as [number, number, number, number], conf: o.conf })),
      verified,
      provisional,
      confidence: Math.round(boosted * 100) / 100,
      firstT: r3(obs[0].t),
      lastT: r3(obs[obs.length - 1].t),
      severity: track.severity,
    });
  }

  // strictness floor applies to the final track confidence
  const passing = kept.filter((track) => {
    if (track.confidence >= threshold) return true;
    guard.belowThreshold.push({ t: track.firstT, hazardClass: track.hazardClass, confidence: track.confidence });
    return false;
  });

  passing.sort((a, b) => a.firstT - b.firstT);
  // cap the display list — a video with more than 12 distinct hazards stays summarized by class
  passing.forEach((track, i) => (track.id = `T${i + 1}`));
  return { tracks: passing.slice(0, 12), guard };
}

/** Observation-weighted mean of final track confidence → the "verified accuracy" metric. */
export function verifiedAccuracy(tracks: VideoTrack[]): number {
  if (tracks.length === 0) return 0;
  let wsum = 0;
  let sum = 0;
  for (const track of tracks) {
    const w = Math.max(1, track.obs.length);
    wsum += w;
    sum += w * track.confidence;
  }
  return Math.round((sum / wsum) * 1000) / 1000;
}

/** Box for playback time t — linearly interpolated between the two bracketing observations. */
export function trackBoxAt(
  track: VideoTrack,
  t: number
): { bbox: [number, number, number, number]; conf: number; alpha: number } | null {
  const PAD = 0.45; // keep the box visible slightly beyond the observations, fading out
  if (t < track.firstT - PAD || t > track.lastT + PAD) return null;
  const obs = track.obs;
  let bbox = obs[0].bbox;
  let conf = obs[0].conf;
  if (t >= obs[obs.length - 1].t) {
    bbox = obs[obs.length - 1].bbox;
    conf = obs[obs.length - 1].conf;
  } else {
    for (let i = 0; i < obs.length - 1; i++) {
      if (t >= obs[i].t && t <= obs[i + 1].t) {
        const span = obs[i + 1].t - obs[i].t || 1;
        const k = (t - obs[i].t) / span;
        bbox = [
          obs[i].bbox[0] + (obs[i + 1].bbox[0] - obs[i].bbox[0]) * k,
          obs[i].bbox[1] + (obs[i + 1].bbox[1] - obs[i].bbox[1]) * k,
          obs[i].bbox[2] + (obs[i + 1].bbox[2] - obs[i].bbox[2]) * k,
          obs[i].bbox[3] + (obs[i + 1].bbox[3] - obs[i].bbox[3]) * k,
        ];
        conf = obs[i].conf + (obs[i + 1].conf - obs[i].conf) * k;
        break;
      }
    }
  }
  // edge fade: full alpha inside the observed window, ramping to 0 across the pad
  const inPad = Math.min(t - (track.firstT - PAD), track.lastT + PAD - t);
  const alpha = Math.max(0, Math.min(1, inPad / PAD));
  return { bbox, conf, alpha };
}

export function formatClock(sec: number): string {
  const s = Math.max(0, sec);
  const m = Math.floor(s / 60);
  const rest = s - m * 60;
  return `${m}:${rest < 10 ? "0" : ""}${rest.toFixed(1)}`;
}
