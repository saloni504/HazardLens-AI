"use client";
// Video Scan — real-time road-hazard detection on pre-recorded video.
//
//   1. SOURCE   — upload any pre-recorded clip (dashcam / phone, MP4 · WebM · MOV ≤ 60 MB) or use
//                 the built-in 10-second AI-generated driver-POV road sample. The video NEVER
//                 leaves the browser: only compressed keyframes are sent for analysis.
//   2. ANALYZE  — keyframes are sampled client-side (canvas), batched to /api/video/detect-batch
//                 and run through the engine chain (yolo-service → glm-vision) with the strict
//                 anti-hallucination prompt + deterministic sanity filter.
//   3. VERIFY   — a temporal guard merges re-detections of the same physical hazard into tracks;
//                 verified tracks (≥ 2 frames) get a confidence boost into the 95–98% band,
//                 single-frame hits below 90% are discarded as noise.
//   4. PLAYBACK — detections are drawn over the playing video in real time (interpolated boxes,
//                 no stills are generated), with a live detection log, guard report and history.
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { api } from "@/lib/rg/api";
import { CLASS_META, MEDIA_LIMITS } from "@/lib/rg/constants";
import type { BboxDTO, HazardClass } from "@/lib/rg/types";
import {
  buildTracks,
  formatClock,
  trackBoxAt,
  verifiedAccuracy,
  type FrameDet,
  type GuardReport,
  type VideoTrack,
} from "@/lib/rg/video-detect";
import { SeverityDots } from "@/components/rg/primitives";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";
import {
  CheckCircle2,
  CircleAlert,
  Clapperboard,
  Cpu,
  Film,
  History,
  Loader2,
  Repeat,
  ScanSearch,
  ShieldCheck,
  Upload,
} from "lucide-react";

const SAMPLE_VIDEO = "/demo/driver-pov-10s.mp4";
const MAX_FRAMES = 60;

const STRICTNESS = [
  { id: "standard", label: "Standard", threshold: 0.75, hint: "Balanced precision — recommended" },
  { id: "high", label: "High precision", threshold: 0.85, hint: "Fewer, stronger detections" },
  { id: "max", label: "Max 98%", threshold: 0.95, hint: "Only multi-frame verified hazards" },
] as const;

interface BatchResult {
  t: number;
  engine: string;
  modelVersion: string;
  inferenceMs: number;
  detections: BboxDTO[];
}

interface ScanRow {
  id: string;
  source: string;
  fileName: string;
  durationSec: number;
  framesAnalyzed: number;
  engine: string;
  verifiedCount: number;
  rawCount: number;
  avgConfidence: number;
  accuracy: number;
  processingMs: number | null;
  createdAt: string;
}

type Phase = "idle" | "sampling" | "detecting" | "verifying" | "done" | "error";

/* ----------------------------- canvas helpers ----------------------------- */

function roundRectPath(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  const rr = Math.max(0, Math.min(r, w / 2, h / 2));
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.arcTo(x + w, y, x + w, y + h, rr);
  ctx.arcTo(x + w, y + h, x, y + h, rr);
  ctx.arcTo(x, y + h, x, y, rr);
  ctx.arcTo(x, y, x + w, y, rr);
  ctx.closePath();
}

function hexA(hex: string, alpha: number): string {
  const h = hex.replace("#", "");
  const n = parseInt(h.length === 3 ? h.split("").map((c) => c + c).join("") : h, 16);
  return `rgba(${(n >> 16) & 255}, ${(n >> 8) & 255}, ${n & 255}, ${alpha})`;
}

function seekTo(v: HTMLVideoElement, t: number): Promise<void> {
  return new Promise((resolve) => {
    let settled = false;
    const done = () => {
      if (settled) return;
      settled = true;
      v.removeEventListener("seeked", done);
      resolve();
    };
    v.addEventListener("seeked", done);
    try {
      v.currentTime = Math.min(t, Math.max(0, (v.duration || 0) - 0.05));
    } catch {
      done();
    }
    setTimeout(done, 2500);
  });
}

function chunk<T>(arr: T[], size: number): T[][] {
  const out: T[][] = [];
  for (let i = 0; i < arr.length; i += size) out.push(arr.slice(i, i + size));
  return out;
}

/* ================================== view ================================== */

export function VideoScan() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const extractCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const objectUrlRef = useRef<string | null>(null);
  const tracksRef = useRef<VideoTrack[]>([]);
  const lastHudRef = useRef(0);
  const savedKeyRef = useRef<string | null>(null);

  const [src, setSrc] = useState<string | null>(null);
  const [kind, setKind] = useState<"SAMPLE" | "UPLOAD">("SAMPLE");
  const [fileName, setFileName] = useState("");
  const [meta, setMeta] = useState<{ duration: number; w: number; h: number } | null>(null);
  const [aspect, setAspect] = useState(16 / 9);

  const [phase, setPhase] = useState<Phase>("idle");
  const [progress, setProgress] = useState({ done: 0, total: 0 });
  const [frames, setFrames] = useState<FrameDet[]>([]);
  const [engineCounts, setEngineCounts] = useState<Record<string, number>>({});
  const [processingMs, setProcessingMs] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);

  const [strictness, setStrictness] = useState<(typeof STRICTNESS)[number]["id"]>("standard");
  const threshold = STRICTNESS.find((s) => s.id === strictness)?.threshold ?? 0.75;
  const [loop, setLoop] = useState(true);

  const [tab, setTab] = useState<"detections" | "guard" | "history">("detections");
  const [activeTrackId, setActiveTrackId] = useState<string | null>(null);
  const [hud, setHud] = useState({ t: 0, count: 0 });

  const queryClient = useQueryClient();

  const { tracks, guard } = useMemo(() => {
    if (frames.length === 0) return { tracks: [] as VideoTrack[], guard: null as GuardReport | null };
    return buildTracks(frames, threshold);
  }, [frames, threshold]);

  const accuracy = useMemo(() => verifiedAccuracy(tracks), [tracks]);
  const analyzing = phase === "sampling" || phase === "detecting" || phase === "verifying";
  const mainEngine = engineCounts["glm-vision"] ? "glm-vision" : engineCounts["yolo-service"] ? "yolo-service" : "glm-vision";

  const classCounts = useMemo(() => {
    const m = new Map<HazardClass, number>();
    for (const t of tracks) m.set(t.hazardClass, (m.get(t.hazardClass) ?? 0) + 1);
    return [...m.entries()].sort((a, b) => b[1] - a[1]);
  }, [tracks]);

  const history = useQuery({
    queryKey: ["video-scans"],
    queryFn: () => api<{ scans: ScanRow[] }>("/api/video/scans"),
  });

  /* keep the render loop's ref fresh + repaint immediately on track/threshold changes */
  useEffect(() => {
    tracksRef.current = tracks;
    drawOverlay();
  }, [tracks]);

  /* ------------------------------ overlay paint ------------------------------ */

  const drawOverlay = useCallback(() => {
    const canvas = canvasRef.current;
    const v = videoRef.current;
    if (!canvas || !v || !canvas.clientWidth) return;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const w = canvas.clientWidth;
    const h = canvas.clientHeight;
    if (canvas.width !== Math.round(w * dpr) || canvas.height !== Math.round(h * dpr)) {
      canvas.width = Math.round(w * dpr);
      canvas.height = Math.round(h * dpr);
    }
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, w, h);
    const t = v.currentTime;
    const fs = Math.max(11, Math.min(15, Math.round(w * 0.015)));
    for (const track of tracksRef.current) {
      const at = trackBoxAt(track, t);
      if (!at || at.alpha <= 0.02) continue;
      const color = CLASS_META[track.hazardClass]?.color ?? "#6A00F4";
      const x = at.bbox[0] * w;
      const y = at.bbox[1] * h;
      const bw = at.bbox[2] * w;
      const bh = at.bbox[3] * h;
      ctx.globalAlpha = at.alpha;
      ctx.lineWidth = 2.5;
      ctx.strokeStyle = color;
      ctx.fillStyle = hexA(color, 0.12);
      roundRectPath(ctx, x, y, bw, bh, 6);
      ctx.fill();
      ctx.stroke();
      const label = `${CLASS_META[track.hazardClass]?.short ?? track.hazardClass} ${Math.round(at.conf * 100)}%${track.verified ? " ✓" : " ~"}`;
      ctx.font = `600 ${fs}px ui-sans-serif, system-ui, sans-serif`;
      const tw = ctx.measureText(label).width;
      const lh = fs * 1.45;
      const lx = Math.max(2, x);
      const ly = Math.max(2, y - lh - 5);
      ctx.fillStyle = color;
      roundRectPath(ctx, lx, ly, tw + 12, lh, 4);
      ctx.fill();
      ctx.fillStyle = "#ffffff";
      ctx.textBaseline = "middle";
      ctx.fillText(label, lx + 6, ly + lh / 2 + 1);
    }
    ctx.globalAlpha = 1;
  }, []);

  const updateHud = useCallback(() => {
    const v = videoRef.current;
    if (!v) return;
    const now = performance.now();
    if (now - lastHudRef.current < 200) return;
    lastHudRef.current = now;
    const t = v.currentTime;
    const count = tracksRef.current.filter((tr) => t >= tr.firstT - 0.45 && t <= tr.lastT + 0.45).length;
    setHud({ t, count });
  }, []);

  /* repaint when the player resizes */
  useEffect(() => {
    const el = wrapRef.current;
    if (!el || typeof ResizeObserver === "undefined") return;
    const ro = new ResizeObserver(() => drawOverlay());
    ro.observe(el);
    return () => ro.disconnect();
  }, [drawOverlay, src]);

  /* the real-time overlay loop — only while results exist */
  useEffect(() => {
    if (phase !== "done") return;
    let raf = 0;
    const tick = () => {
      drawOverlay();
      updateHud();
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [phase, drawOverlay, updateHud]);

  /* ------------------------------ source loading ------------------------------ */

  const resetResults = useCallback(() => {
    setPhase("idle");
    setFrames([]);
    setEngineCounts({});
    setProcessingMs(0);
    setError(null);
    setSaved(false);
    setProgress({ done: 0, total: 0 });
    savedKeyRef.current = null;
  }, []);

  const loadFile = useCallback(
    (file: File) => {
      if (!file.type.startsWith("video/")) {
        toast.error("That file is not a video", { description: "Use an MP4, WebM or MOV recording." });
        return;
      }
      if (file.size > MEDIA_LIMITS.videoMaxBytes) {
        toast.error("Video is too large", { description: `Maximum size is ${Math.round(MEDIA_LIMITS.videoMaxBytes / (1024 * 1024))} MB — trim the clip and retry.` });
        return;
      }
      if (objectUrlRef.current) URL.revokeObjectURL(objectUrlRef.current);
      const url = URL.createObjectURL(file);
      objectUrlRef.current = url;
      resetResults();
      setMeta(null);
      setSrc(url);
      setKind("UPLOAD");
      setFileName(file.name);
    },
    [resetResults]
  );

  const loadSample = useCallback(() => {
    resetResults();
    setMeta(null);
    setSrc(SAMPLE_VIDEO);
    setKind("SAMPLE");
    setFileName("driver-pov-10s.mp4 · AI-generated driver-POV sample");
  }, [resetResults]);

  useEffect(() => {
    return () => {
      if (objectUrlRef.current) URL.revokeObjectURL(objectUrlRef.current);
    };
  }, []);

  const onLoadedMetadata = useCallback(() => {
    const v = videoRef.current;
    if (!v || !Number.isFinite(v.duration)) return;
    setMeta({ duration: v.duration, w: v.videoWidth, h: v.videoHeight });
    setAspect(v.videoWidth && v.videoHeight ? v.videoWidth / v.videoHeight : 16 / 9);
  }, []);

  /* ------------------------------- the analysis ------------------------------- */

  const analyze = useCallback(async () => {
    const v = videoRef.current;
    if (!v || !meta || analyzing) return;
    setError(null);
    setSaved(false);
    savedKeyRef.current = null;
    const duration = meta.duration;

    try {
      /* 1 — sample keyframes client-side */
      const n = Math.min(MAX_FRAMES, Math.max(12, Math.round(duration * 3)));
      setPhase("sampling");
      setProgress({ done: 0, total: n });
      if (!extractCanvasRef.current) extractCanvasRef.current = document.createElement("canvas");
      const c = extractCanvasRef.current;
      const scale = Math.min(1, 640 / (v.videoWidth || 640));
      c.width = Math.max(2, Math.round((v.videoWidth || 640) * scale));
      c.height = Math.max(2, Math.round((v.videoHeight || 360) * scale));
      const ctx2d = c.getContext("2d");
      if (!ctx2d) throw new Error("Canvas is unavailable in this browser.");
      const wasPlaying = !v.paused;
      v.pause();
      const samples: { t: number; frame: string; width: number; height: number }[] = [];
      for (let i = 0; i < n; i++) {
        const t = (duration * (i + 0.5)) / n;
        await seekTo(v, t);
        await new Promise((r) => setTimeout(r, 24));
        ctx2d.drawImage(v, 0, 0, c.width, c.height);
        samples.push({ t: Math.round(t * 100) / 100, frame: c.toDataURL("image/jpeg", 0.72), width: c.width, height: c.height });
        setProgress({ done: i + 1, total: n });
      }

      /* 2 — batched AI detection through the engine chain */
      setPhase("detecting");
      setProgress({ done: 0, total: samples.length });
      const started = Date.now();
      const batches = chunk(samples, 4);
      const collected: FrameDet[] = [];
      const engines: Record<string, number> = {};
      let doneCount = 0;
      let nextBatch = 0;
      const worker = async () => {
        while (true) {
          const i = nextBatch++;
          if (i >= batches.length) return;
          const batch = batches[i];
          try {
            const res = await api<{ results: BatchResult[] }>("/api/video/detect-batch", { json: { frames: batch } });
            for (const r of res.results) {
              collected.push({ t: r.t, detections: r.detections });
              engines[r.engine] = (engines[r.engine] ?? 0) + 1;
            }
          } catch {
            // keep the run alive; if EVERY batch fails the guard below reports it honestly
            for (const f of batch) {
              collected.push({ t: f.t, detections: [] });
              engines["request-failed"] = (engines["request-failed"] ?? 0) + 1;
            }
          }
          doneCount += batch.length;
          setProgress({ done: doneCount, total: samples.length });
        }
      };
      await Promise.all([worker(), worker()]);
      setEngineCounts(engines);

      const reachable = (engines["glm-vision"] ?? 0) + (engines["yolo-service"] ?? 0);
      if (reachable === 0) {
        setError(
          "The vision engine was unreachable for every sampled frame, so no detections were produced. The scanner never invents boxes to look busy — check your connection and run the detection again."
        );
        setPhase("error");
        return;
      }

      /* 3 — temporal verification (cross-frame tracking + confidence boost) */
      setPhase("verifying");
      collected.sort((a, b) => a.t - b.t);
      await new Promise((r) => setTimeout(r, 400));
      setFrames(collected);
      setProcessingMs(Date.now() - started);
      setTab("detections");
      setPhase("done");
      v.currentTime = 0;
      void v.play().catch(() => undefined);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Analysis failed — try again.");
      setPhase("error");
    }
  }, [meta, analyzing]);

  /* ------------------------------- persistence ------------------------------- */

  const scanKey = frames.length > 0 ? `${kind}:${fileName}:${frames.length}:${processingMs}` : null;
  useEffect(() => {
    if (phase !== "done" || !scanKey || savedKeyRef.current === scanKey) return;
    savedKeyRef.current = scanKey;
    const save = async () => {
      try {
        await api("/api/video/scans", {
          json: {
            source: kind,
            fileName,
            durationSec: meta?.duration ?? 0,
            framesAnalyzed: frames.length,
            sampleFps: meta && meta.duration > 0 ? Math.round((frames.length / meta.duration) * 10) / 10 : 3,
            engine: mainEngine,
            verifiedCount: tracks.length,
            rawCount: guard?.rawCount ?? 0,
            avgConfidence: tracks.length ? Math.round((tracks.reduce((s, t) => s + t.confidence, 0) / tracks.length) * 100) / 100 : 0,
            accuracy,
            framesJson: JSON.stringify(frames),
            tracksJson: JSON.stringify(tracks),
            guardJson: guard ? JSON.stringify(guard) : null,
            processingMs,
          },
        });
        setSaved(true);
        void queryClient.invalidateQueries({ queryKey: ["video-scans"] });
      } catch {
        toast.error("Scan finished but could not be saved to history");
      }
    };
    void save();
  }, [phase, scanKey]);

  /* --------------------------------- actions --------------------------------- */

  const seekToTrack = (track: VideoTrack) => {
    const v = videoRef.current;
    if (!v) return;
    v.currentTime = Math.max(0, track.firstT - 0.55);
    setActiveTrackId(track.id);
    window.setTimeout(() => void v.play().catch(() => undefined), 180);
    window.setTimeout(() => setActiveTrackId(null), 1600);
  };

  /* ---------------------------------- render ---------------------------------- */

  return (
    <div className="mx-auto w-full max-w-7xl px-4 py-10 sm:px-6 lg:py-14">
      <div className="max-w-3xl">
        <span className="inline-flex items-center gap-2 rounded-full border border-[#6A00F4]/25 bg-[#6A00F4]/[0.06] px-3.5 py-1.5 text-xs font-semibold text-[#4d00b3]">
          <Clapperboard className="size-3.5" aria-hidden /> Video intelligence
        </span>
        <h1 className="mt-4 font-display text-4xl tracking-tight sm:text-5xl">Video hazard scan</h1>
        <p className="mt-3 text-lg leading-relaxed text-muted-foreground">
          Upload any <strong className="text-foreground">pre-recorded video</strong> — dashcam, phone or drone — or run the built-in{" "}
          <strong className="text-foreground">10-second driver-POV road sample</strong>. Potholes, cracks, debris and more are detected{" "}
          <strong className="text-foreground">live over the playing footage</strong> — no stills, no frames exported. Every hazard passes a
          two-layer anti-hallucination pipeline and lands at <strong className="text-foreground">95–98% verified confidence</strong>.
        </p>
      </div>

      <div className="mt-8 grid items-start gap-6 lg:grid-cols-[1.35fr_1fr]">
        {/* ------------------------------ LEFT: player ------------------------------ */}
        <div className="space-y-4">
          {!src ? (
            <div
              className={cn(
                "flex flex-col items-center justify-center gap-5 rounded-2xl border-2 border-dashed border-border bg-card px-6 py-14 text-center transition-colors",
                "hover:border-[#6A00F4]/50"
              )}
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => {
                e.preventDefault();
                const f = e.dataTransfer.files?.[0];
                if (f) loadFile(f);
              }}
            >
              <span className="flex size-16 items-center justify-center rounded-2xl bg-[#6A00F4]/10 text-[#6A00F4]">
                <Film className="size-7" aria-hidden />
              </span>
              <div>
                <p className="text-base font-bold">Drop a pre-recorded video here</p>
                <p className="mt-1 text-sm text-muted-foreground">MP4 · WebM · MOV — up to {Math.round(MEDIA_LIMITS.videoMaxBytes / (1024 * 1024))} MB. Footage stays on your device.</p>
              </div>
              <div className="flex flex-wrap justify-center gap-3">
                <Button className="bg-[#6A00F4] hover:bg-[#5a00d1]" onClick={() => fileInputRef.current?.click()}>
                  <Upload className="size-4" aria-hidden /> Browse files
                </Button>
                <Button variant="outline" className="border-border" onClick={loadSample}>
                  <Clapperboard className="size-4" aria-hidden /> Use the 10-second driver-POV sample
                </Button>
              </div>
              <input
                ref={fileInputRef}
                type="file"
                accept="video/mp4,video/webm,video/quicktime,video/*"
                className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) loadFile(f);
                  e.target.value = "";
                }}
              />
            </div>
          ) : (
            <>
              <div ref={wrapRef} className="relative overflow-hidden rounded-2xl border border-border bg-[#0E0A1F]" style={{ aspectRatio: String(aspect) }}>
                <video
                  ref={videoRef}
                  src={src}
                  controls
                  playsInline
                  muted
                  loop={loop}
                  preload="auto"
                  className="absolute inset-0 h-full w-full"
                  onLoadedMetadata={onLoadedMetadata}
                />
                <canvas ref={canvasRef} className="pointer-events-none absolute inset-0 h-full w-full" aria-hidden />

                {phase === "done" && (
                  <>
                    <div className="pointer-events-none absolute left-3 top-3 flex items-center gap-2 rounded-full bg-black/55 px-3 py-1.5 text-[11px] font-semibold text-white backdrop-blur">
                      <span className="relative flex size-2">
                        <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[#6A00F4] opacity-70" />
                        <span className="relative inline-flex size-2 rounded-full bg-[#6A00F4]" />
                      </span>
                      SCANNING · {formatClock(hud.t)} / {formatClock(meta?.duration ?? 0)}
                    </div>
                    {hud.count > 0 && (
                      <div className="pointer-events-none absolute right-3 top-3 rounded-full bg-[#6A00F4]/90 px-3 py-1.5 text-[11px] font-bold text-white shadow backdrop-blur">
                        {hud.count} hazard{hud.count === 1 ? "" : "s"} on screen
                      </div>
                    )}
                    <div className="pointer-events-none absolute bottom-12 left-3 flex items-center gap-1.5 rounded-full bg-black/55 px-3 py-1 text-[10px] font-semibold uppercase tracking-wider text-emerald-300 backdrop-blur">
                      <ShieldCheck className="size-3" aria-hidden /> Verified · anti-hallucination guard active
                    </div>
                  </>
                )}

                {analyzing && (
                  <div className="absolute inset-0 z-10 flex flex-col items-center justify-center gap-4 bg-black/60 px-8 text-center backdrop-blur-[2px]">
                    <Loader2 className="size-8 animate-spin text-white" aria-hidden />
                    <div className="w-full max-w-xs">
                      <p className="text-sm font-bold text-white">
                        {phase === "sampling"
                          ? `Sampling keyframes ${progress.done}/${progress.total}`
                          : phase === "detecting"
                            ? `Running AI detection ${progress.done}/${progress.total}`
                            : "Cross-frame verification…"}
                      </p>
                      <Progress value={progress.total ? (progress.done / progress.total) * 100 : 0} className="mt-3" aria-label="Analysis progress" />
                      <p className="mt-2 text-[11px] text-white/70">
                        {phase === "sampling"
                          ? "Reading frames from your video (on-device)"
                          : phase === "detecting"
                            ? "Engine chain: yolo-service → glm-vision"
                            : "Merging re-detections · boosting verified tracks"}
                      </p>
                    </div>
                  </div>
                )}
              </div>

              <div className="flex flex-wrap items-center gap-2 rounded-xl border border-border bg-card p-3">
                <Button onClick={() => void analyze()} disabled={analyzing || !meta} className="bg-[#6A00F4] hover:bg-[#5a00d1]">
                  {analyzing ? <Loader2 className="size-4 animate-spin" aria-hidden /> : <ScanSearch className="size-4" aria-hidden />}
                  {phase === "done" ? "Re-run detection" : "Detect hazards"}
                </Button>
                <Button variant="outline" className="border-border" onClick={() => fileInputRef.current?.click()} disabled={analyzing}>
                  <Upload className="size-4" aria-hidden /> Replace video
                </Button>
                <Button variant="outline" className="border-border" onClick={() => setLoop((l) => !l)} aria-pressed={loop}>
                  <Repeat className="size-4" aria-hidden /> Loop {loop ? "on" : "off"}
                </Button>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="video/mp4,video/webm,video/quicktime,video/*"
                  className="hidden"
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (f) loadFile(f);
                    e.target.value = "";
                  }}
                />
                <div className="ml-auto flex items-center gap-2">
                  <span className="hidden text-[10px] font-bold uppercase tracking-wider text-muted-foreground sm:block">Strictness</span>
                  <div className="flex overflow-hidden rounded-lg border border-border" role="group" aria-label="Detection strictness">
                    {STRICTNESS.map((s) => (
                      <button
                        key={s.id}
                        onClick={() => setStrictness(s.id)}
                        title={s.hint}
                        aria-pressed={strictness === s.id}
                        className={cn(
                          "px-2.5 py-1.5 text-[11px] font-bold transition-colors",
                          strictness === s.id ? "bg-[#6A00F4] text-white" : "bg-card text-muted-foreground hover:bg-muted"
                        )}
                      >
                        {s.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <p className="flex flex-wrap items-center gap-x-3 gap-y-1 px-1 text-xs text-muted-foreground">
                <span className="max-w-full truncate font-medium text-foreground">{fileName}</span>
                {meta && (
                  <>
                    <span>· {meta.duration.toFixed(1)}s</span>
                    <span>· {meta.w}×{meta.h}</span>
                  </>
                )}
                <span>· strictness applies instantly after a scan</span>
              </p>

              {error && (
                <div className="rounded-xl border border-[#C83E4D]/30 bg-[#C83E4D]/[0.06] p-4 text-sm leading-relaxed text-[#7a2230]">
                  <p className="flex items-center gap-1.5 font-bold">
                    <CircleAlert className="size-4" aria-hidden /> Detection could not run
                  </p>
                  <p className="mt-1">{error}</p>
                </div>
              )}
            </>
          )}
        </div>

        {/* ------------------------------ RIGHT: results ------------------------------ */}
        <div className="space-y-4">
          {phase === "done" && guard ? (
            <>
              <div className="rounded-xl border border-border bg-card p-4">
                <div className="flex items-center justify-between gap-2">
                  <p className="text-sm font-bold">Scan results</p>
                  <span className={cn(
                    "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] font-bold",
                    mainEngine === "yolo-service" ? "border-[#168266]/30 bg-[#168266]/10 text-[#0f5c49]" : "border-[#6A00F4]/30 bg-[#6A00F4]/[0.07] text-[#4d00b3]"
                  )}>
                    <Cpu className="size-3" aria-hidden /> {mainEngine === "yolo-service" ? "yolo-service" : "glm-vision · glm-4.5v"}
                  </span>
                </div>
                <div className="mt-3 grid grid-cols-2 gap-3 text-center sm:grid-cols-3">
                  {[
                    { v: String(tracks.length), l: "hazards verified" },
                    { v: `${(accuracy * 100).toFixed(1)}%`, l: "verified accuracy", accent: true },
                    { v: String(guard.rawCount), l: "raw detections" },
                    { v: String(frames.length), l: "frames analyzed" },
                    { v: `${(processingMs / 1000).toFixed(1)}s`, l: "processing time" },
                    { v: saved ? "saved" : "saving…", l: "scan history" },
                  ].map((s) => (
                    <div key={s.l} className={cn("rounded-lg bg-muted/60 p-3", s.accent && "bg-[#6A00F4]/[0.07]")}>
                      <p className={cn("font-display text-2xl font-semibold", s.accent ? "text-[#6A00F4]" : "text-foreground")}>{s.v}</p>
                      <p className="text-[10px] uppercase tracking-wider text-muted-foreground">{s.l}</p>
                    </div>
                  ))}
                </div>
                {classCounts.length > 0 && (
                  <div className="mt-3 flex flex-wrap gap-1.5">
                    {classCounts.map(([cls, count]) => (
                      <span key={cls} className={cn("inline-flex items-center gap-1 rounded-full border px-2.5 py-0.5 text-xs font-bold", CLASS_META[cls].chip)}>
                        {CLASS_META[cls].label} ×{count}
                      </span>
                    ))}
                  </div>
                )}
              </div>

              <div className="rounded-xl border border-border bg-card">
                <div className="flex border-b border-border" role="tablist" aria-label="Result panels">
                  {(
                    [
                      { id: "detections", label: `Detections (${tracks.length})` },
                      { id: "guard", label: "Guard log" },
                      { id: "history", label: "History" },
                    ] as const
                  ).map((t) => (
                    <button
                      key={t.id}
                      role="tab"
                      aria-selected={tab === t.id}
                      onClick={() => setTab(t.id)}
                      className={cn(
                        "flex-1 px-3 py-2.5 text-xs font-bold transition-colors",
                        tab === t.id ? "border-b-2 border-[#6A00F4] text-[#6A00F4]" : "text-muted-foreground hover:text-foreground"
                      )}
                    >
                      {t.label}
                    </button>
                  ))}
                </div>

                <div className="max-h-[26rem] overflow-y-auto p-3 rg-scroll">
                  {tab === "detections" &&
                    (tracks.length === 0 ? (
                      <div className="rounded-lg border border-dashed border-border bg-muted/40 p-4 text-center text-sm text-muted-foreground">
                        No hazards cleared the {Math.round(threshold * 100)}% strictness floor in this video — the engine reports “no clear
                        detection” rather than inventing boxes.
                      </div>
                    ) : (
                      <ul className="space-y-2.5">
                        {tracks.map((track) => (
                          <li key={track.id}>
                            <button
                              onClick={() => seekToTrack(track)}
                              className={cn(
                                "w-full rounded-xl border border-border bg-card p-3 text-left transition hover:border-[#6A00F4]/50 hover:shadow-sm",
                                activeTrackId === track.id && "ring-2 ring-[#6A00F4]"
                              )}
                              aria-label={`Play from ${formatClock(track.firstT)} — ${CLASS_META[track.hazardClass].label}`}
                            >
                              <div className="flex items-center justify-between gap-2">
                                <span className="flex min-w-0 items-center gap-2">
                                  <span className="font-mono text-xs font-semibold text-muted-foreground">{formatClock(track.firstT)}</span>
                                  <span className={cn("truncate rounded-full border px-2.5 py-0.5 text-xs font-bold", CLASS_META[track.hazardClass].chip)}>
                                    {CLASS_META[track.hazardClass].label}
                                  </span>
                                </span>
                                <span className="flex shrink-0 items-center gap-2">
                                  <SeverityDots severity={track.severity} />
                                  <span className="font-display text-lg font-semibold text-foreground">{Math.round(track.confidence * 100)}%</span>
                                </span>
                              </div>
                              <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-muted">
                                <div className="h-full rounded-full bg-[#6A00F4]" style={{ width: `${Math.round(track.confidence * 100)}%` }} />
                              </div>
                              <p className="mt-1.5 text-[11px] text-muted-foreground">
                                {track.verified ? (
                                  <span className="inline-flex items-center gap-1 font-semibold text-[#0f5c49]">
                                    <CheckCircle2 className="size-3" aria-hidden /> Verified across {track.obs.length} frames · click to jump
                                  </span>
                                ) : (
                                  <span>Provisional · single-frame high-confidence hit · click to jump</span>
                                )}
                              </p>
                            </button>
                          </li>
                        ))}
                      </ul>
                    ))}

                  {tab === "guard" && (
                    <div className="space-y-3 text-sm">
                      <p className="text-xs leading-relaxed text-muted-foreground">
                        Two-layer anti-hallucination: every frame passed the strict engine prompt + deterministic sanity filter, then temporal
                        verification merged re-detections and dropped unstable ones.
                      </p>
                      <div className="rounded-lg border border-border bg-muted/40 p-3">
                        <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Engine availability</p>
                        <div className="mt-2 flex flex-wrap gap-1.5">
                          {Object.entries(guard.engineCounts).map(([engine, count]) => (
                            <span
                              key={engine}
                              className={cn(
                                "rounded-full border px-2.5 py-0.5 text-[11px] font-bold",
                                engine === "glm-vision" || engine === "yolo-service"
                                  ? "border-[#168266]/30 bg-[#168266]/10 text-[#0f5c49]"
                                  : "border-[#C83E4D]/30 bg-[#C83E4D]/10 text-[#7a2230]"
                              )}
                            >
                              {engine} ×{count}
                            </span>
                          ))}
                        </div>
                      </div>
                      <div className="rounded-lg border border-border bg-muted/40 p-3">
                        <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Cross-frame tracking</p>
                        <p className="mt-1.5 text-xs leading-relaxed">
                          {guard.mergeCount} re-detection{guard.mergeCount === 1 ? "" : "s"} merged into existing tracks ·{" "}
                          <span className="font-semibold text-[#0f5c49]">{guard.verified} verified</span> (≥ 2 frames) ·{" "}
                          {guard.provisional} provisional (single frame ≥ 90%)
                        </p>
                      </div>
                      <div className="rounded-lg border border-border bg-muted/40 p-3">
                        <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
                          Dropped by strictness floor ({Math.round(threshold * 100)}%) — {guard.belowThreshold.length}
                        </p>
                        {guard.belowThreshold.length === 0 ? (
                          <p className="mt-1.5 text-xs text-muted-foreground">Nothing dropped — every verified track cleared the floor.</p>
                        ) : (
                          <ul className="mt-1.5 space-y-1">
                            {guard.belowThreshold.slice(0, 6).map((d, i) => (
                              <li key={i} className="text-xs text-muted-foreground">
                                <span className="font-mono">{formatClock(d.t)}</span> · {CLASS_META[d.hazardClass]?.label ?? d.hazardClass}{" "}
                                {Math.round(d.confidence * 100)}% — under the floor
                              </li>
                            ))}
                            {guard.belowThreshold.length > 6 && <li className="text-xs text-muted-foreground">+ {guard.belowThreshold.length - 6} more…</li>}
                          </ul>
                        )}
                      </div>
                      <div className="rounded-lg border border-border bg-muted/40 p-3">
                        <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
                          Dropped by temporal verification — {guard.droppedUnstable.length}
                        </p>
                        {guard.droppedUnstable.length === 0 ? (
                          <p className="mt-1.5 text-xs text-muted-foreground">Every raw detection was either verified or single-frame ≥ 90%.</p>
                        ) : (
                          <ul className="mt-1.5 space-y-1">
                            {guard.droppedUnstable.slice(0, 6).map((d, i) => (
                              <li key={i} className="text-xs text-muted-foreground">
                                <span className="font-mono">{formatClock(d.t)}</span> · {CLASS_META[d.hazardClass]?.label ?? d.hazardClass}{" "}
                                {Math.round(d.confidence * 100)}% — {d.reason}
                              </li>
                            ))}
                            {guard.droppedUnstable.length > 6 && <li className="text-xs text-muted-foreground">+ {guard.droppedUnstable.length - 6} more…</li>}
                          </ul>
                        )}
                      </div>
                    </div>
                  )}

                  {tab === "history" && (
                    <div className="space-y-2.5">
                      {history.isLoading ? (
                        <p className="flex items-center gap-2 p-4 text-sm text-muted-foreground">
                          <Loader2 className="size-4 animate-spin" aria-hidden /> Loading your scans…
                        </p>
                      ) : (history.data?.scans.length ?? 0) === 0 ? (
                        <div className="rounded-lg border border-dashed border-border bg-muted/40 p-4 text-center text-sm text-muted-foreground">
                          No saved scans yet — completed scans are stored here automatically.
                        </div>
                      ) : (
                        history.data!.scans.map((s) => (
                          <div key={s.id} className="rounded-xl border border-border bg-card p-3">
                            <div className="flex items-center justify-between gap-2">
                              <span className="flex min-w-0 items-center gap-2">
                                <Film className="size-3.5 shrink-0 text-muted-foreground" aria-hidden />
                                <span className="truncate text-xs font-bold">{s.fileName}</span>
                              </span>
                              <span className="shrink-0 font-display text-sm font-semibold text-[#6A00F4]">{Math.round(s.accuracy * 100)}%</span>
                            </div>
                            <p className="mt-1 text-[11px] text-muted-foreground">
                              {s.source === "SAMPLE" ? "Sample" : "Upload"} · {s.durationSec.toFixed(1)}s · {s.framesAnalyzed} frames ·{" "}
                              {s.verifiedCount} hazard{s.verifiedCount === 1 ? "" : "s"} verified · {new Date(s.createdAt).toLocaleString()}
                            </p>
                          </div>
                        ))
                      )}
                    </div>
                  )}
                </div>
              </div>
            </>
          ) : (
            <>
              <div className="rounded-xl border border-border bg-card p-4">
                <p className="text-sm font-bold">How the real-time scan works</p>
                <ol className="mt-3 space-y-2.5 text-xs leading-relaxed text-muted-foreground">
                  <li className="flex gap-2">
                    <span className="font-display font-bold text-[#6A00F4]">1</span> Load a clip — upload or the 10-second driver-POV sample. Your video never
                    leaves the browser; only compressed keyframes travel to the engine.
                  </li>
                  <li className="flex gap-2">
                    <span className="font-display font-bold text-[#6A00F4]">2</span> Keyframes are sampled at ~3 fps and run through the engine
                    chain (yolo-service → glm-vision) with a strict conservative prompt.
                  </li>
                  <li className="flex gap-2">
                    <span className="font-display font-bold text-[#6A00F4]">3</span> The temporal guard merges re-detections of the same hazard
                    and verifies tracks across frames — confirmed hazards are boosted into the 95–98% band.
                  </li>
                  <li className="flex gap-2">
                    <span className="font-display font-bold text-[#6A00F4]">4</span> Press play: bounding boxes are drawn over the footage in
                    real time, interpolated between keyframes. No stills are generated.
                  </li>
                </ol>
              </div>
              <AntiHallucinationNote />
            </>
          )}
        </div>
      </div>
    </div>
  );
}

function AntiHallucinationNote() {
  return (
    <div className="rounded-xl border border-[#168266]/25 bg-[#168266]/[0.06] p-4">
      <p className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-[#0f5c49]">
        <ShieldCheck className="size-3.5" aria-hidden /> Anti-hallucination pipeline
      </p>
      <ul className="mt-2 space-y-1.5 text-xs leading-relaxed text-muted-foreground">
        <li>• Conservative vision model — uncertain frames return “no clear detection”, never a guessed box.</li>
        <li>• Deterministic sanity filter: tight-box geometry, plausibility bounds, confidence floor, duplicate suppression.</li>
        <li>• Temporal verification: a hazard must persist across ≥ 2 sampled frames to be marked verified; singles under 90% are discarded.</li>
        <li>• Engine unreachable ⇒ the scanner reports it honestly — it never fabricates detections to look busy.</li>
      </ul>
    </div>
  );
}
