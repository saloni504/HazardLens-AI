// /api/uploads — validated media upload (multipart/form-data).
//
// Pipeline (see src/lib/rg/media.ts):
//   1. magic-byte content sniffing — the declared Content-Type is never trusted
//   2. size/type gates (images ≤ 12 MB jpg/png, video ≤ 60 MB mp4/webm/mov)
//   3. EXIF-GPS extraction ONLY when the uploader gives explicit consent
//   4. unconditional metadata strip — images are re-encoded, dropping EXIF entirely
//   5. 8×8 perceptual hash (aHash) for the duplicate-detection engine
// Response 201 { mediaId, mimeType, width, height, suggestedLocation, note }
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { clientIp, writeAudit } from "@/lib/rg/audit";
import { rateLimit } from "@/lib/rg/ratelimit";
import { sha256 } from "@/lib/rg/auth";
import { perceptualHash, safeResolve, storeUpload, validateUpload } from "@/lib/rg/media";

export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  // Uploads are heavy (≤ 60 MB) — keep the public gate tight: 30 files / 10 min / IP.
  const gate = rateLimit(`uploads:${clientIp(req)}`, 30, 10 * 60_000);
  if (!gate.ok) {
    return NextResponse.json(
      { error: "Too many uploads — please wait a moment.", detail: `Retry in ${gate.retryAfterSec}s.` },
      { status: 429, headers: { "Retry-After": String(gate.retryAfterSec) } }
    );
  }

  let form: FormData;
  try {
    form = await req.formData();
  } catch {
    return NextResponse.json({ error: "Expected multipart/form-data with a `file` field." }, { status: 400 });
  }

  const file = form.get("file");
  if (!(file instanceof File) || file.size === 0) {
    return NextResponse.json({ error: "No file received — attach an image or video and retry." }, { status: 400 });
  }

  // geoConsent arrives as an explicit checkbox value from the report form.
  const extractGps = String(form.get("geoConsent") ?? "false") === "true";

  const declaredMime = file.type || "application/octet-stream";
  const sizeOk = validateUpload(declaredMime, file.size);
  if (!sizeOk.ok) {
    return NextResponse.json(
      { error: sizeOk.error ?? "Upload rejected." },
      { status: /exceeds/i.test(sizeOk.error ?? "") ? 413 : 415 }
    );
  }

  const buffer = Buffer.from(await file.arrayBuffer());

  // Magic-byte verification — unverifiable media (mismatched/forged signatures) is rejected.
  const stored = await storeUpload(buffer, declaredMime, { extractGps }).catch((err) => {
    console.error("[uploads] store failed", err);
    return null;
  });
  if (!stored) {
    return NextResponse.json({ error: "Could not process this media — unsupported or corrupted file." }, { status: 415 });
  }

  const asset = await db.mediaAsset.create({
    data: {
      kind: "ORIGINAL",
      storagePath: stored.storagePath,
      mimeType: stored.mimeType,
      sizeBytes: stored.sizeBytes,
      width: stored.width ?? null,
      height: stored.height ?? null,
      checksum: sha256(buffer),
    },
  });

  // Perceptual fingerprint (images only) — powers duplicate-evidence similarity.
  if (stored.mimeType === "image/jpeg" || stored.mimeType === "image/png") {
    const abs = safeResolve(stored.storagePath);
    if (abs) {
      const phash = await perceptualHash(abs);
      if (phash) await db.mediaAsset.update({ where: { id: asset.id }, data: { perceptualHash: phash } });
    }
  }

  const note = stored.gps
    ? "EXIF location found — review the suggested pin below."
    : "Metadata stripped for privacy.";

  await writeAudit({
    action: "media.upload",
    entityType: "media_asset",
    entityId: asset.id,
    metadata: { mimeType: stored.mimeType, sizeBytes: stored.sizeBytes, gpsExtracted: Boolean(stored.gps) },
    ip: clientIp(req),
  });

  return NextResponse.json(
    {
      mediaId: asset.id,
      mimeType: stored.mimeType,
      width: stored.width ?? null,
      height: stored.height ?? null,
      suggestedLocation: stored.gps ?? null,
      note,
    },
    { status: 201 }
  );
}
