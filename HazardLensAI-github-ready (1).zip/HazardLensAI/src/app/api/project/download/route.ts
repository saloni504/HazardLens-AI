// GET /api/project/download — one-click download of the GitHub-ready project archive.
// Streams public/HazardLensAI-github-ready.zip as a real attachment; when the archive has
// not been built yet (fresh clone) it responds 404 with a regeneration hint.
import { NextResponse } from "next/server";
import { promises as fs } from "fs";
import path from "path";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const ZIP_PATH = path.join(process.cwd(), "public", "HazardLensAI-github-ready.zip");

export async function GET() {
  try {
    const data = await fs.readFile(ZIP_PATH);
    return new NextResponse(new Uint8Array(data), {
      headers: {
        "Content-Type": "application/zip",
        "Content-Length": String(data.length),
        "Content-Disposition": 'attachment; filename="HazardLensAI-github-ready.zip"',
        "Cache-Control": "no-store",
      },
    });
  } catch {
    return NextResponse.json(
      { error: "Project archive not built yet.", detail: "Run the packaging step to produce public/HazardLensAI-github-ready.zip, then retry." },
      { status: 404 }
    );
  }
}
