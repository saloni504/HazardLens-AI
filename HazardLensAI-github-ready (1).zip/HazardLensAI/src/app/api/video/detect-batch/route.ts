// /api/video/detect-batch — stateless batch frame inference for the Video Scan studio.
// The client samples frames from a pre-recorded video (canvas → JPEG → base64) and posts them
// in small batches. Each frame runs through the engine chain (yolo-service → glm-vision) with
// the same strict anti-hallucination validation as the live webcam studio. No database writes;
// when the vision engine is unreachable the frame reports engine "live-unavailable" with an
// EMPTY detection set — boxes are never fabricated.
import { NextRequest, NextResponse } from "next/server";
import { getAuth } from "@/lib/rg/auth";
import { clientIp, writeAudit } from "@/lib/rg/audit";
import { rateLimit } from "@/lib/rg/ratelimit";
import { runFrameInference } from "@/lib/rg/inference";

export const runtime = "nodejs";
export const maxDuration = 120;

interface FrameIn {
  t?: number;
  frame?: string;
  width?: number;
  height?: number;
}

const MAX_BATCH = 6;

function parseDataUrl(s: string): { mime: string; buffer: Buffer } | null {
  const m = s.match(/^data:(image\/(?:jpeg|png|webp));base64,(.+)$/);
  const mime = m ? m[1] : "image/jpeg";
  const b64 = m ? m[2] : s;
  if (!b64 || b64.length < 100) return null;
  let buffer: Buffer;
  try {
    buffer = Buffer.from(b64, "base64");
  } catch {
    return null;
  }
  if (buffer.length < 1024) return null;
  if (buffer.length > 8 * 1024 * 1024) return null;
  return { mime, buffer };
}

/** Small promise pool so a batch of frames is analyzed with bounded parallelism. */
async function mapWithConcurrency<T, R>(items: T[], limit: number, fn: (item: T) => Promise<R>): Promise<R[]> {
  const out: R[] = new Array(items.length);
  let next = 0;
  const workers = Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (true) {
      const i = next++;
      if (i >= items.length) return;
      out[i] = await fn(items[i]);
    }
  });
  await Promise.all(workers);
  return out;
}

export async function POST(req: NextRequest) {
  const auth = await getAuth(req);
  if (!auth?.userId) {
    return NextResponse.json({ error: "Sign in to run video detection." }, { status: 401 });
  }

  const rl = rateLimit(`video-batch:${clientIp(req)}`, 240, 60 * 1000); // 240 frames / min / IP
  if (!rl.ok) {
    return NextResponse.json(
      { error: "Video detection rate limit reached (240 frames/min).", detail: `Retry after ${rl.retryAfterSec}s.` },
      { status: 429, headers: { "Retry-After": String(rl.retryAfterSec) } }
    );
  }

  const body = (await req.json().catch(() => null)) as { frames?: FrameIn[] } | null;
  const framesIn = Array.isArray(body?.frames) ? body!.frames!.slice(0, MAX_BATCH) : [];
  if (framesIn.length === 0) {
    return NextResponse.json({ error: "`frames` (1–6 items of { t, frame }) is required." }, { status: 400 });
  }

  const parsed = framesIn.map((f) => {
    const t = Number.isFinite(f.t) ? Math.max(0, Number(f.t)) : 0;
    const parsedFrame = typeof f.frame === "string" ? parseDataUrl(f.frame) : null;
    return {
      t,
      ok: parsedFrame !== null,
      mime: parsedFrame?.mime ?? "image/jpeg",
      buffer: parsedFrame?.buffer ?? Buffer.alloc(0),
      width: Number.isFinite(f.width) ? Number(f.width) : null,
      height: Number.isFinite(f.height) ? Number(f.height) : null,
    };
  });

  const bad = parsed.findIndex((p) => !p.ok);
  if (bad !== -1) {
    return NextResponse.json(
      { error: `Frame at index ${bad} is missing, corrupted, or exceeds 8 MB — re-sample and retry.` },
      { status: 400 }
    );
  }

  const started = Date.now();
  const results = await mapWithConcurrency(parsed, 3, async (p) => {
    const r = await runFrameInference(p.buffer, p.mime, { width: p.width, height: p.height });
    return {
      t: Math.round(p.t * 100) / 100,
      engine: r.engine,
      modelVersion: r.modelVersion,
      inferenceMs: r.inferenceMs,
      detections: r.detections,
    };
  });
  const elapsedMs = Date.now() - started;

  await writeAudit({
    actorId: auth.userId,
    action: "inference.video_batch",
    entityType: "video_scan",
    entityId: null,
    metadata: { frames: results.length, elapsedMs, engines: results.map((r) => r.engine) },
    ip: clientIp(req),
  });

  return NextResponse.json({ results, elapsedMs });
}
