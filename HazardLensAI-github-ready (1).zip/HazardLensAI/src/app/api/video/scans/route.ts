// /api/video/scans — persistence for completed Video Scan sessions.
//   POST — save a finished scan (detection timeline + verified tracks + guard report).
//   GET  — the current user's recent scans (light payload: no JSON blobs).
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getAuth } from "@/lib/rg/auth";
import { clientIp, writeAudit } from "@/lib/rg/audit";

export const runtime = "nodejs";

const MAX_JSON_CHARS = 5_000_000; // SQLite TEXT guard — timelines are ~10 KB in practice

function clampStr(v: unknown, max: number): string | null {
  if (typeof v !== "string" || v.length === 0) return null;
  return v.length > max ? v.slice(0, max) : v;
}

function clampNum(v: unknown, min: number, max: number, fallback = 0): number {
  const n = Number(v);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, n));
}

export async function POST(req: NextRequest) {
  const auth = await getAuth(req);
  if (!auth?.userId) {
    return NextResponse.json({ error: "Sign in to save video scans." }, { status: 401 });
  }

  const body = (await req.json().catch(() => null)) as Record<string, unknown> | null;
  if (!body) return NextResponse.json({ error: "Invalid JSON body." }, { status: 400 });

  const framesJson = clampStr(body.framesJson, MAX_JSON_CHARS);
  const tracksJson = clampStr(body.tracksJson, MAX_JSON_CHARS);
  if (!framesJson || !tracksJson) {
    return NextResponse.json({ error: "framesJson and tracksJson are required." }, { status: 400 });
  }

  const source = body.source === "SAMPLE" ? "SAMPLE" : "UPLOAD";
  const engine = clampStr(body.engine, 60) ?? "glm-vision";

  const scan = await db.videoScan.create({
    data: {
      userId: auth.userId,
      source,
      fileName: clampStr(body.fileName, 200) ?? (source === "SAMPLE" ? "driver-pov-10s.mp4" : "video"),
      durationSec: clampNum(body.durationSec, 0, 3600),
      framesAnalyzed: Math.round(clampNum(body.framesAnalyzed, 1, 400, 1)),
      sampleFps: clampNum(body.sampleFps, 0.1, 30, 3),
      engine,
      verifiedCount: Math.round(clampNum(body.verifiedCount, 0, 999)),
      rawCount: Math.round(clampNum(body.rawCount, 0, 9999)),
      avgConfidence: clampNum(body.avgConfidence, 0, 1),
      accuracy: clampNum(body.accuracy, 0, 1),
      framesJson,
      tracksJson,
      guardJson: clampStr(body.guardJson, MAX_JSON_CHARS),
      processingMs: Math.round(clampNum(body.processingMs, 0, 3_600_000)),
    },
  });

  await writeAudit({
    actorId: auth.userId,
    action: "video_scan.save",
    entityType: "video_scan",
    entityId: scan.id,
    metadata: { source, durationSec: scan.durationSec, verifiedCount: scan.verifiedCount, accuracy: scan.accuracy },
    ip: clientIp(req),
  });

  return NextResponse.json({ id: scan.id, createdAt: scan.createdAt }, { status: 201 });
}

export async function GET(req: NextRequest) {
  const auth = await getAuth(req);
  if (!auth?.userId) {
    return NextResponse.json({ error: "Sign in to view video scans." }, { status: 401 });
  }

  const scans = await db.videoScan.findMany({
    where: { userId: auth.userId },
    orderBy: { createdAt: "desc" },
    take: 8,
    select: {
      id: true,
      source: true,
      fileName: true,
      durationSec: true,
      framesAnalyzed: true,
      sampleFps: true,
      engine: true,
      verifiedCount: true,
      rawCount: true,
      avgConfidence: true,
      accuracy: true,
      processingMs: true,
      createdAt: true,
    },
  });

  return NextResponse.json({ scans });
}
